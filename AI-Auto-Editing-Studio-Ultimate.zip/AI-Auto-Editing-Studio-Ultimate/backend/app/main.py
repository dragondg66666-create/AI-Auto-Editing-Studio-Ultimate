from fastapi import FastAPI
from pydantic import BaseModel, Field
from uuid import uuid4

app = FastAPI(
    title="AI Auto Editing Studio API",
    version="0.1.0",
    description="Backend starter for orchestration and asynchronous production jobs."
)

PROJECTS: dict[str, dict] = {}
JOBS: dict[str, dict] = {}

class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    brief: str = Field(min_length=1, max_length=10000)
    language: str = "ar-EG"
    target_formats: list[str] = ["16:9", "9:16"]

class StageRequest(BaseModel):
    stage: str
    input_data: dict = {}

@app.get("/health")
def health():
    return {"status": "ok", "service": "ai-video-studio-api", "version": "0.1.0"}

@app.post("/v1/projects")
def create_project(payload: ProjectCreate):
    project_id = str(uuid4())
    project = {
        "id": project_id,
        **payload.model_dump(),
        "status": "created",
        "current_stage": "BRIEF_ANALYSIS",
        "visual_bible": {},
        "continuity_state": {},
        "created_assets": [],
    }
    PROJECTS[project_id] = project
    return project

@app.get("/v1/projects/{project_id}")
def get_project(project_id: str):
    return PROJECTS.get(project_id, {"error": "project_not_found"})

@app.post("/v1/projects/{project_id}/jobs")
def submit_stage(project_id: str, payload: StageRequest):
    if project_id not in PROJECTS:
        return {"error": "project_not_found"}
    job_id = str(uuid4())
    job = {
        "id": job_id,
        "project_id": project_id,
        "stage": payload.stage,
        "input_data": payload.input_data,
        "status": "queued",
        "note": "Queue/worker integration is a later milestone."
    }
    JOBS[job_id] = job
    return job

@app.get("/v1/jobs/{job_id}")
def get_job(job_id: str):
    return JOBS.get(job_id, {"error": "job_not_found"})
