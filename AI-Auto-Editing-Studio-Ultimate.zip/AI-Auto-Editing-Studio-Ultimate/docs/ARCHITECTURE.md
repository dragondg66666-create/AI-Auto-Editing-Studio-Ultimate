# Architecture

## Core rule
All subsystems operate on one `ProductionProject` identity and shared contracts. No stage should invent or silently fork project truth.

## Logical layers
- Android client: project creation, review, approvals, progress, asset browser, export controls.
- API gateway: authentication, validation, project/job endpoints.
- Orchestrator: dependency graph, retries, idempotency, checkpoints, cancellation.
- Domain engines: niche, script, visual bible, storyboard, prompts, generation, continuity, audio, editing, QC, export.
- Providers: Gemini or other LLMs, image/video generation APIs, TTS, speech recognition, FFmpeg.
- Infrastructure: relational DB, object storage, queue, GPU workers, logs and metrics.

## Required shared records
- Project: brief, target audience, language, formats, desired duration.
- Visual Bible: immutable approved character/environment/style references and explicit allowed changes.
- Scene: ordered shots, timing, narrative state, references.
- Clip: provider, model, seed when available, input references, output asset, duration, status.
- Continuity checkpoint: previous clip, last-frame asset, character positions/actions, camera state, environment state.
- Job: stage, dependencies, status, attempt count, error, timestamps, outputs.

## Continuity protocol
1. Persist the approved scene state and clip metadata.
2. Extract the previous clip's final frame on the backend.
3. Pass that frame as a reference only when the selected generation provider supports it.
4. Pass structured state (pose, screen position, movement direction, camera, lighting, environment).
5. Generate the next clip.
6. Run visual and temporal checks against locked attributes and expected state.
7. If a check fails, create a targeted repair job; do not silently rewrite the Visual Bible.
8. Record unresolved limitations for user review.

Last-frame conditioning improves continuity but cannot guarantee pixel-perfect or physically perfect continuity across all generative models.

## Job orchestration
Use durable jobs, idempotency keys, bounded retries, cancellation, checkpoints and resumability. Do not keep long-running GPU work inside an HTTP request.
