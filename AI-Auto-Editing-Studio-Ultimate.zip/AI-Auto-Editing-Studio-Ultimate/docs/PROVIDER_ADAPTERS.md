# Provider adapter design

Each provider adapter should declare capabilities rather than assuming all models behave alike.

Suggested capability fields:
- supports_text_to_image
- supports_image_to_video
- supports_first_frame
- supports_last_frame
- supports_audio_generation
- supported_aspect_ratios
- max_clip_duration_seconds
- reference_image_limit
- commercial_use_terms_url
- estimated_cost

The orchestration engine chooses a provider based on required capabilities, quality, latency, cost, region and user settings. Provider-specific request/response formats must remain inside adapter modules.
