# Google AI Studio integration notes

- AI Studio Build can create native Android applications with Kotlin and Jetpack Compose.
- Android mode is currently client-side and has a narrower supported project shape than a full backend deployment.
- Treat the Android application as the control/review client.
- Deploy FastAPI, queues, GPU workers, FFmpeg and storage independently.
- Keep provider credentials on the backend or in supported secret management. Never place private keys in source code or the APK.
- Import this GitHub repository from Build mode using Add files (+) → Import from GitHub.
- If the Android importer cannot interpret the monorepo, import the Android Gradle project portion or create the Android shell in AI Studio and link/sync the repository using the supported GitHub workflow.
- Verify current platform support before relying on any feature; AI Studio capabilities can change.
