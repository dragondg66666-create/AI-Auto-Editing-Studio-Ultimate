# Master prompt for Google AI Studio

You are continuing an existing Android application repository named AI Auto Editing Studio Ultimate.

IMPORTANT:
- Build a native Android APK application using Kotlin and Jetpack Compose.
- Do not convert it into a website, React app, Expo app, or Flutter app.
- First inspect the complete existing repository and summarize its current architecture.
- Preserve the existing package name `com.aivideostudio.ultimate`, app identity, project contracts, production stages, and folder structure.
- Do not delete working files or replace the whole project with a demo.
- Implement changes in small verified milestones. After each milestone, run available checks and fix compilation errors before continuing.
- The app is the user-facing control center. Heavy video/image generation, FFmpeg rendering, queues, and provider secrets belong in the separately deployed backend.
- All engines must share one ProductionProject, VisualBible, scene state, asset registry, and job system.

PRODUCT:
Create a premium, professional AI production studio. The user can enter a video idea or upload source media. The system analyzes requirements, recommends niches and ideas, writes title/hook/script/CTA, creates a complete storyboard, designs character and environment references, generates prompts for image/video/audio providers, orchestrates generation, preserves continuity between clips, creates voice/subtitles/sound, edits the timeline, performs quality checks and exports long videos plus Shorts/Reels.

NON-NEGOTIABLE SYSTEM RULES:
1. One unified project model and API contract across every engine.
2. Durable jobs with queued/running/succeeded/failed/cancelled states, retries, checkpoints and resume.
3. Visual Bible with locked character identity, clothing, environment, style and camera rules; only explicitly allowed story changes may vary.
4. Continuity state must include previous clip, last-frame asset reference, character pose/position/action, camera state and environment state.
5. Use last-frame conditioning only when the selected video provider supports it; never claim perfect continuity.
6. Every generated asset must have metadata: project, scene, shot, provider, model, prompt version, references, status and rights/source.
7. Provider adapters must be replaceable; do not hard-code one vendor into domain logic.
8. Never expose API keys in Android source, APK, logs or Git history.
9. Provide Arabic (Egyptian) UI first, with architecture ready for English and other languages.
10. User can review/edit/approve stages, while default workflow can run automatically after explicit project settings.

FIRST MILESTONE:
Improve the current Compose UI into a polished navigation shell with:
- Dashboard
- New Project wizard
- Project workspace and production pipeline
- Script & Hook studio
- Visual Bible / Character Lab
- Storyboard & Shot List
- Prompt Studio
- Generation Queue
- Continuity Monitor
- Audio & Dubbing
- Timeline Editor
- Quality Control
- Export Center
- Settings / Provider Connections

Use mock repository data only where backend endpoints are not yet implemented. Clearly label mock functionality. Do not pretend generation or rendering is working until connected to a real provider/backend.
