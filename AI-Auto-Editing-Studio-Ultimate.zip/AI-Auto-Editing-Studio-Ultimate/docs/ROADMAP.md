# Delivery roadmap

## M0 — Foundation
- Import Android shell into AI Studio.
- Confirm navigation, theme, project form and APK build.
- Preserve this repository as the source of truth.

## M1 — Connected project foundation
- Add authentication and backend base URL configuration.
- Implement project CRUD, job status polling and persistent storage.
- Add upload manager and asset metadata.

## M2 — Creative planning
- Brief analyzer, niche research, idea generator.
- Hook/script/CTA writer and structured scene outline.
- User-editable production specification.

## M3 — Visual pre-production
- Visual Bible and locked attributes.
- Character/environment reference assets.
- Storyboard, shot list, camera and lighting plan.
- Prompt studio with provider-neutral prompt records.

## M4 — Generation providers
- Provider adapters for image, video, speech and sound.
- Capability registry: image reference, first/last frame, duration, aspect ratio, audio.
- Cost estimates, quotas and failure handling.

## M5 — Continuity
- Last-frame extraction and state checkpointing.
- Character/environment consistency checks.
- Targeted clip regeneration and continuity report.

## M6 — Audio and editing
- Voice profiles, TTS, transcription, subtitles and sound design.
- Timeline schema and FFmpeg worker.
- Long-form render and short-form derivatives.

## M7 — Quality and export
- QC gates, repair queue, export presets.
- Metadata, thumbnail prompt, captions and publishing handoff.

## M8 — Production hardening
- Security review, observability, load tests, backups, privacy and cost controls.
- Provider license and commercial-use review.
