# Security, privacy and rights

- Keep all provider secrets server-side.
- Require authentication and per-project authorization before exposing assets or job results.
- Validate uploads by MIME type, file size, duration and supported codecs.
- Use signed, expiring URLs for private media.
- Log job IDs and safe metadata, not API keys or private user content.
- Obtain rights or permission for source footage, reference images, generated voices, music and publishing destinations.
- Use official platform APIs and user authorization for publishing. Do not automate prohibited scraping or spam.
- Provide deletion/export controls and retention policies for user projects.
