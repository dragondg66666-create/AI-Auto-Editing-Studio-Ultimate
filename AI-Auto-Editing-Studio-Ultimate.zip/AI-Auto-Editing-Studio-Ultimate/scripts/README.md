# Scripts

Automation scripts will be added here as the repository grows. Do not add scripts that require private tokens in command-line arguments or commit secrets.
