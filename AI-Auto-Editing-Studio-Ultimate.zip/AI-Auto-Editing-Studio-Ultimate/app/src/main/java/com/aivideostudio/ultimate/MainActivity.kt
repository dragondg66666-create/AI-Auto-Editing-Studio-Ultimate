package com.aivideostudio.ultimate

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.aivideostudio.ultimate.ui.StudioApp
import com.aivideostudio.ultimate.ui.theme.StudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioTheme { StudioApp() } }
    }
}
