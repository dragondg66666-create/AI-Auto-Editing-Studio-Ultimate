package com.aivideostudio.ultimate.core.orchestration

import com.aivideostudio.ultimate.core.model.ProductionProject
import com.aivideostudio.ultimate.core.model.ProductionStage

/**
 * Client-side coordinator contract.
 * Actual long-running generation is delegated to the backend job API.
 */
interface ProductionOrchestrator {
    suspend fun createProject(name: String, brief: String): ProductionProject
    suspend fun startStage(projectId: String, stage: ProductionStage): String
    suspend fun getProject(projectId: String): ProductionProject
    suspend fun resumeProject(projectId: String)
}
