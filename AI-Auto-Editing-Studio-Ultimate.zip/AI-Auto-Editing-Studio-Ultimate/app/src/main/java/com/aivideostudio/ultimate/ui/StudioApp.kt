package com.aivideostudio.ultimate.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private val stages = listOf(
    "تحليل الفكرة والمتطلبات", "اكتشاف النيتش والأفكار", "السكريبت والـ Hook",
    "الشخصيات والعالم البصري", "Storyboard واللقطات", "Prompts الإنتاج",
    "توليد الصور والفيديو", "استمرارية المشاهد والثوابت", "الصوت والتعريب",
    "المونتاج الذكي", "فحص الجودة والإصلاح", "التصدير والنشر"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioApp() {
    var projectName by remember { mutableStateOf("مشروعي الأول") }
    var brief by remember { mutableStateOf("") }
    var selected by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("AI Video Production Studio") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("استوديو الإنتاج الذكي", style = MaterialTheme.typography.headlineSmall)
                Text("من الفكرة إلى الفيديو النهائي — في مشروع مترابط واحد")
            }
            item {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    label = { Text("اسم المشروع") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = brief,
                    onValueChange = { brief = it },
                    label = { Text("اكتب فكرتك أو مواصفات الفيديو") },
                    placeholder = { Text("مثال: فيلم قصير كرتوني عن...") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Button(
                    onClick = { selected = 0 },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = brief.isNotBlank()
                ) { Text("تحليل الفكرة وبدء خطة الإنتاج") }
            }
            item { Text("مراحل الإنتاج", style = MaterialTheme.typography.titleLarge) }
            items(stages) { stage ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(stage)
                        Text("قيد التجهيز", color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
            item {
                Text(
                    "هذه نسخة تأسيسية للواجهة. ربط المحركات الفعلية وخادم التوليد سيتم على مراحل.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
