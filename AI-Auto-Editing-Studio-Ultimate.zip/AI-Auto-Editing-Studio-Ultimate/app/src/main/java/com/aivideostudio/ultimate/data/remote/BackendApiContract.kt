package com.aivideostudio.ultimate.data.remote

/**
 * Replace this contract with a Retrofit/Ktor implementation after backend deployment.
 * Keep provider secrets on the backend; never embed them in the APK.
 */
interface BackendApiContract {
    suspend fun health(): String
    suspend fun createProject(name: String, brief: String): String
    suspend fun submitStage(projectId: String, stage: String): String
    suspend fun getJob(jobId: String): String
    suspend fun getProject(projectId: String): String
}
