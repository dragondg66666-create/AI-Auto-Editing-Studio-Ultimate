package com.aivideostudio.ultimate.core.model

data class ProductionProject(
    val id: String,
    val name: String,
    val brief: String,
    val language: String = "ar-EG",
    val targetFormats: List<String> = listOf("16:9", "9:16"),
    val stage: ProductionStage = ProductionStage.BRIEF_ANALYSIS,
    val visualBible: VisualBible = VisualBible(),
    val continuity: ContinuityState = ContinuityState()
)

enum class ProductionStage {
    BRIEF_ANALYSIS, NICHE_RESEARCH, SCRIPT, VISUAL_BIBLE, STORYBOARD,
    PROMPTS, ASSET_GENERATION, CONTINUITY, AUDIO, EDITING, QUALITY_CONTROL, EXPORT
}

data class VisualBible(
    val artStyle: String = "",
    val palette: List<String> = emptyList(),
    val lockedAttributes: Map<String, String> = emptyMap(),
    val characters: List<CharacterReference> = emptyList(),
    val environments: List<EnvironmentReference> = emptyList()
)

data class CharacterReference(
    val id: String,
    val name: String,
    val identityDescription: String,
    val referenceAssetIds: List<String> = emptyList(),
    val voiceProfileId: String? = null
)

data class EnvironmentReference(
    val id: String,
    val name: String,
    val description: String,
    val referenceAssetIds: List<String> = emptyList()
)

data class ContinuityState(
    val previousSceneId: String? = null,
    val previousClipId: String? = null,
    val lastFrameAssetId: String? = null,
    val characterStates: Map<String, String> = emptyMap(),
    val environmentState: String = "",
    val unresolvedIssues: List<String> = emptyList()
)
