# AI Auto Editing Studio Ultimate

Native Android AI video-production studio scaffold.

**Target:** Android APK  
**Android UI:** Kotlin + Jetpack Compose  
**Backend direction:** FastAPI + background workers + object storage/GPU providers  
**Architecture:** one project model, one orchestration contract, connected production stages.

> This repository is an engineering starter scaffold, not a finished AI video generator. Real image/video generation, GPU rendering, cloud storage, authentication, and publishing require provider integrations and deployed infrastructure.

## Product workflow
1. Brief intake and requirement analysis
2. Niche and audience research
3. Idea, title, hook, script and CTA generation
4. Visual Bible: characters, environments, style and locked attributes
5. Complete storyboard and shot list
6. Prompt generation for image, video, voice and sound providers
7. Image and clip generation
8. Continuity management using previous scene state and last-frame references
9. Voice, dubbing, subtitles and sound design
10. Timeline assembly and editing
11. Quality checks and targeted repair
12. Export long-form video and derived Shorts/Reels packages

## Repository map
- `app/`: native Android application (single Gradle app module)
- `backend/`: separate FastAPI service starter; deploy independently
- `contracts/`: shared API and data contracts
- `docs/`: architecture, roadmap, safety, provider integration notes
- `.github/workflows/`: Android CI build workflow

## Open in Google AI Studio
1. Create a new GitHub repository and upload/push this repository.
2. In Google AI Studio, open **Build** and choose **Android**.
3. Use **Add files (+) → Import from GitHub** and select this repository.
4. If the importer rejects extra folders or does not recognize the Android project, import the Android project from `app/` only or create the native Android shell in AI Studio and sync it with GitHub.
5. Ask the agent to inspect the existing code first, preserve the architecture, and implement one milestone at a time. Use `docs/AI_STUDIO_MASTER_PROMPT.md`.

Official AI Studio Android projects use Kotlin and Jetpack Compose. Android mode is currently client-side and has constraints; keep GPU/video processing in the separately deployed backend. See `docs/GOOGLE_AI_STUDIO_NOTES.md`.

## Build locally (optional)
Requires JDK 17 and Android SDK:
```bash
./gradlew assembleDebug
```
Windows:
```bat
gradlew.bat assembleDebug
```

## Backend local development (optional)
Requires Python 3.11+:
```bash
cd backend
python -m venv .venv
# Activate the environment, then:
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Security
- Never commit API keys, access tokens, signing keys, service-account JSON, or `.env` files.
- Use AI Studio Secrets / Firebase App Check where supported, and backend secret management for server-side provider credentials.
- Do not expose provider API keys in the APK.
- Use only assets, voices, music, and source footage you have rights to use.
